from __future__ import annotations
import json, yaml
import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from src.auto_orchestrator import AutoOrchestrator
from src.live_analytics import account_performance, positions_table, decisions_table, latest_by_asset_horizon, problem_ranking, latest_prices_table

load_dotenv(); st.set_page_config(page_title="V6 Live Dashboard",layout="wide",page_icon="📊")
with open("config.yaml","r",encoding="utf-8") as f: cfg=yaml.safe_load(f)
engine=AutoOrchestrator(float(cfg["research"]["initial_capital"])); db=engine.db; lab=engine.lab

st.title("V6 Live Simulation Dashboard")
st.caption("只看結果與數據｜本地虛擬資金｜交易訂單 API = 0｜行情 SQLite 快取＋節流更新")

c1,c2,c3,c4=st.columns(4)
c1.metric("虛擬帳戶","6")
c2.metric("ACTIVE 標的",len(db.assets()))
c3.metric("目前持倉",len(db.positions()))
c4.metric("交易訂單 API","0")

if st.button("立即完整更新",type="primary",use_container_width=True):
    with st.spinner("自動匯入標的 → 校準到期模型 → 補行情 → 算短中長決策 → 更新本地模擬倉..."):
        r=engine.full_cycle(force_recalibrate=False)
        st.session_state["last_manual_cycle"]=r
r=st.session_state.get("last_manual_cycle")
if r:
    sim=r.get("simulation",{})
    if r.get("status")=="OK": st.success(f"完成：處理 {sim.get('bars_processed',0)} 根新 K；行情 API {sim.get('market_data_api_calls',0)} 次；交易 API 0 次。")
    else: st.warning(r)

@st.fragment(run_every="30s")
def live_results():
    prices=latest_prices_table(db,engine.cache)
    st.subheader("最新行情（本機快取）")
    if prices.empty: st.info("尚未建立行情快取。背景 Worker 啟動後會自動補資料。")
    else:
        px=prices.copy(); px["漲跌"]=px.change_pct.map(lambda x:f"{x*100:+.2f}%")
        st.dataframe(px[["bar_time","market","symbol","price","漲跌","volume"]],use_container_width=True,hide_index=True)

    acct=account_performance(db,lab)
    st.subheader("六個等本金帳戶")
    if not acct.empty:
        a=acct.copy(); a["報酬率"]=a.return_pct.map(lambda x:f"{x*100:.2f}%"); a["回撤"]=a.drawdown.map(lambda x:f"{x*100:.2f}%")
        a["勝率"]=a.win_rate.map(lambda x:"—" if pd.isna(x) else f"{x*100:.1f}%"); a["PF"]=a.profit_factor.map(lambda x:"—" if pd.isna(x) else ("∞" if x==float('inf') else f"{x:.2f}"))
        st.dataframe(a[["account_id","initial_equity","equity","報酬率","cash","gross_exposure","leverage","回撤","positions","closed_trades","勝率","PF"]],use_container_width=True,hide_index=True)

    pos=positions_table(db,engine.cache)
    st.subheader("目前持倉")
    if pos.empty: st.info("目前沒有持倉。")
    else:
        p=pos.copy(); p["未實現報酬"]=p.return_pct.map(lambda x:f"{x*100:.2f}%"); p["未實現P/L"]=p.unrealized_pnl.map(lambda x:f"{x:,.2f}")
        st.dataframe(p[["account_id","symbol","週期","strategy","entry_price","mark_price","未實現P/L","未實現報酬","leverage_at_entry","stop_price","target_price","bars_held"]],use_container_width=True,hide_index=True)

    latest=latest_by_asset_horizon(db)
    st.subheader("最新短／中／長決策")
    if latest.empty: st.info("尚未產生決策。")
    else:
        v=latest.sort_values(["action","trade_confidence"],ascending=[True,False]).copy()
        v["Trade信心"]=v.trade_confidence.map(lambda x:f"{x:.1f}"); v["模型信心"]=v.model_confidence.map(lambda x:f"{x:.1f}"); v["訊號強度"]=v.signal_strength.map(lambda x:f"{x:.1f}")
        st.dataframe(v[["bar_time","market","symbol","週期","strategy","action","Trade信心","模型信心","訊號強度","regime","requested_notional","leverage","reason"]],use_container_width=True,hide_index=True)

    problems=problem_ranking(db)
    st.subheader("策略問題排名")
    if problems.empty: st.info("已平倉樣本還太少，等待累積後會自動找出失效組合。")
    else:
        q=problems.copy(); q["勝率"]=q.win_rate.map(lambda x:f"{x*100:.1f}%"); q["平均報酬"]=q.avg_return.map(lambda x:f"{x*100:.2f}%"); q["PF"]=q.profit_factor.map(lambda x:"—" if pd.isna(x) else ("∞" if x==float('inf') else f"{x:.2f}"))
        st.dataframe(q[["symbol","週期","strategy","regime","samples","勝率","PF","平均報酬","realized_pnl","問題"]].head(30),use_container_width=True,hide_index=True)

    trades=pd.DataFrame(db.recent_trades(100))
    st.subheader("最近已平倉")
    if trades.empty: st.info("尚無已平倉交易。")
    else: st.dataframe(trades[[c for c in ["exit_bar","account_id","symbol","strategy","horizon","realized_pnl","return_pct","exit_reason","leverage"] if c in trades.columns]],use_container_width=True,hide_index=True)

    dec=decisions_table(db,500)
    if not dec.empty:
        last=pd.to_datetime(dec.bar_time,utc=True,errors="coerce").max()
        st.caption(f"最新決策資料時間：{last}｜畫面每 30 秒只讀本機資料庫；背景 Worker 才會依節流規則補行情。")

live_results()

with st.expander("研究/維護工具"):
    st.write("完整研究頁仍保留在 app.py。平常只需要這個 Dashboard；要重新大篩選或查 Stage 3/4/5/6 細節時才開研究頁。")
    if st.button("強制重新校準全部模型"):
        with st.spinner("重新校準所有 ACTIVE 標的 × 短中長..."):
            x=engine.calibrate_due(force=True)
        st.write(x)
